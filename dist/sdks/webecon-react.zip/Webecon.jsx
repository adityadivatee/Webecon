/**
 * Webecon React SDK - v17.2 PRO
 * Developed by Aditya Divte Production (aka Aditya Diwate)
 * Website: https://adityadivte.com
 * Visit https://webecon.adityadivte.com for more info.
 */

import React from 'react';
export const Webecon = ({ name, ...props }) => <webecon-icon name={name} {...props} />;
export const Icon = (name) => (props) => <webecon-icon name={name} {...props} />;