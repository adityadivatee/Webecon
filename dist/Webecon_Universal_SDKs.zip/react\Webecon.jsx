/**
 * Webecon React SDK - v17.2 PRO
 * Copyright (c) 2026 Aditya Divte Production (adityadivte.com)
 * 
 * Commercial Use: Allowed | Resale: Forbidden | Branding Removal: Forbidden
 * 
 * Visit https://adityadivte.com for more professional tools and elite UI assets.
 */

import React from 'react';
export const Webecon = ({ name, ...props }) => <webecon-icon name={name} {...props} />;
export const Icon = (name) => (props) => <webecon-icon name={name} {...props} />;